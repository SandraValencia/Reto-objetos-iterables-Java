package org.iterable;

import java.util.ArrayList;
import java.util.Arrays;

public class Main {

    public static void main(String[] args) {

        ArrayList<Integer> numeros = new ArrayList<Integer>();

        for (int i=1; i<=100; i++){
            numeros.add(i);
        }

        System.out.println(numeros);

        int suma = 0;
        int promedio = 0;

        for (int i=0; i< numeros.size(); i++){
            suma = suma + numeros.get(i);
        }

        promedio = suma / numeros.size();

        System.out.println(promedio);

        for (int i=101; i<=150; i++){
            numeros.add(i);
        }

        System.out.println(numeros);
    }
}
